#!/usr/bin/env python3
"""
Test script to verify API key integration and functionality
"""
import os
import sys
import logging

def test_api_keys():
    """Test if API keys are properly configured"""
    print("🔍 Checking API Key Configuration...")
    print("-" * 50)
    
    # Check OpenAI API Key
    openai_key = os.environ.get("OPENAI_API_KEY")
    if openai_key:
        print(f"✅ OPENAI_API_KEY: Found (length: {len(openai_key)} chars)")
        if openai_key.startswith("sk-"):
            print("   Format looks correct")
        else:
            print("   ⚠️  Warning: Key doesn't start with 'sk-'")
    else:
        print("❌ OPENAI_API_KEY: Not found")
    
    # Check Anthropic API Key
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if anthropic_key:
        print(f"✅ ANTHROPIC_API_KEY: Found (length: {len(anthropic_key)} chars)")
        if anthropic_key.startswith("sk-ant-"):
            print("   Format looks correct")
        else:
            print("   ⚠️  Warning: Key doesn't start with 'sk-ant-'")
    else:
        print("❌ ANTHROPIC_API_KEY: Not found")
    
    print("\n🧪 Testing API Integration...")
    print("-" * 50)
    
    # Test OpenAI
    if openai_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=openai_key)
            
            # Test with a simple request
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Test: Say 'API working'"}],
                max_tokens=10
            )
            
            result = response.choices[0].message.content
            print(f"✅ OpenAI API Test: SUCCESS - Response: {result}")
            return True
            
        except Exception as e:
            print(f"❌ OpenAI API Test: FAILED - {str(e)}")
    
    # Test Anthropic
    if anthropic_key:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_key)
            
            response = client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=10,
                messages=[{"role": "user", "content": "Test: Say 'API working'"}]
            )
            
            result = response.content[0].text if response.content else "No response"
            print(f"✅ Anthropic API Test: SUCCESS - Response: {result}")
            return True
            
        except Exception as e:
            print(f"❌ Anthropic API Test: FAILED - {str(e)}")
    
    if not openai_key and not anthropic_key:
        print("ℹ️  No API keys configured - using local analysis mode")
    
    return False

def test_chatbot_integration():
    """Test the actual chatbot integration"""
    print("\n🤖 Testing Chatbot Integration...")
    print("-" * 50)
    
    try:
        from ai_service import get_ai_response
        
        test_message = "What programs are available?"
        response = get_ai_response(test_message)
        
        print(f"Test Query: {test_message}")
        print(f"Response: {response[:200]}...")
        
        if "ChatGPT" in response or "API" in response:
            print("✅ AI API integration detected in response")
        else:
            print("ℹ️  Using local analysis mode")
            
        return True
        
    except Exception as e:
        print(f"❌ Chatbot Integration Test: FAILED - {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 College Chatbot API Integration Test")
    print("=" * 60)
    
    api_working = test_api_keys()
    chatbot_working = test_chatbot_integration()
    
    print("\n📊 Summary:")
    print("-" * 50)
    if api_working:
        print("✅ API Integration: WORKING")
    else:
        print("⚠️  API Integration: Using local analysis (add API key for enhanced responses)")
    
    if chatbot_working:
        print("✅ Chatbot System: WORKING")
    else:
        print("❌ Chatbot System: NEEDS ATTENTION")
    
    print("\n💡 To add your OpenAI API key:")
    print("   1. Go to https://platform.openai.com/api-keys")
    print("   2. Create a new API key")
    print("   3. Add it to your environment variables")
    print("   4. Restart the application")