#!/usr/bin/env python3
"""
One-click setup script for local development
This script will set up everything needed to run the chatbot locally
"""

import os
import sys
import subprocess
import platform

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"📦 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e}")
        print(f"Output: {e.stdout}")
        print(f"Error: {e.stderr}")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    env_file = '.env'
    if not os.path.exists(env_file):
        print("📝 Creating .env file...")
        with open(env_file, 'w') as f:
            f.write("""# College Query Chatbot - Environment Variables

# Required - Get from Google AI Studio (https://aistudio.google.com/app/apikey)
GEMINI_API_KEY=your_gemini_api_key_here

# Optional - Session security (change for production)
SESSION_SECRET=dev-secret-key-change-in-production

# Optional - Database URL (defaults to SQLite)
DATABASE_URL=sqlite:///instance/chatbot.db

# Development settings
FLASK_ENV=development
FLASK_DEBUG=True
""")
        print("✅ .env file created successfully")
        print("⚠️  Please edit .env and add your Gemini API key!")
        return False
    else:
        print("✅ .env file already exists")
        return True

def create_directories():
    """Create necessary directories"""
    directories = ['instance', 'static/css', 'static/js', 'templates']
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"📁 Created directory: {directory}")

def main():
    """Main setup function"""
    print("🎓 College Query Chatbot - Local Setup")
    print("=" * 50)
    
    # Check Python version
    if sys.version_info < (3, 9):
        print("❌ Python 3.9 or higher is required")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    
    print(f"✅ Python version: {sys.version.split()[0]}")
    
    # Create directories
    create_directories()
    
    # Create virtual environment
    venv_command = "python -m venv venv"
    if not run_command(venv_command, "Creating virtual environment"):
        print("❌ Failed to create virtual environment")
        sys.exit(1)
    
    # Determine activation command based on OS
    if platform.system() == "Windows":
        activate_cmd = "venv\\Scripts\\activate"
        pip_cmd = "venv\\Scripts\\pip"
    else:
        activate_cmd = "source venv/bin/activate"
        pip_cmd = "venv/bin/pip"
    
    # Install dependencies
    install_cmd = f"{pip_cmd} install -r local_requirements.txt"
    if not run_command(install_cmd, "Installing Python packages"):
        print("❌ Failed to install dependencies")
        sys.exit(1)
    
    # Create .env file
    env_exists = create_env_file()
    
    print("\n🎉 Setup completed successfully!")
    print("=" * 50)
    
    if not env_exists:
        print("⚠️  IMPORTANT: Please edit the .env file and add your Gemini API key")
        print("   Get your API key from: https://aistudio.google.com/app/apikey")
        print("")
    
    print("🚀 To start the application:")
    print(f"   1. Activate virtual environment: {activate_cmd}")
    print("   2. Run: python run_local.py")
    print("   3. Open: http://localhost:5000")
    print("")
    print("📚 See README.md for detailed instructions")

if __name__ == "__main__":
    main()