#!/usr/bin/env python3
"""
Docker Deployment Script for College Query Chatbot
Creates Docker containerized deployment with one command
"""

import os
import sys
import subprocess
import json
from pathlib import Path

class DockerDeployment:
    def __init__(self):
        self.project_name = "college-query-chatbot"
        self.image_name = f"{self.project_name}:latest"
        self.container_name = f"{self.project_name}-container"
        self.port = 5000
        
    def create_dockerfile(self):
        """Create optimized Dockerfile"""
        dockerfile_content = """# College Query Chatbot - Docker Image
FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    gcc \\
    g++ \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY local_requirements.txt requirements.txt

# Install Python dependencies
RUN pip install --no-cache-dir --upgrade pip && \\
    pip install --no-cache-dir -r requirements.txt

# Copy application files
COPY . .

# Create instance directory for SQLite
RUN mkdir -p instance

# Expose port
EXPOSE 5000

# Set environment variables
ENV FLASK_APP=main.py
ENV FLASK_ENV=production
ENV PYTHONPATH=/app

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:5000/ || exit 1

# Run the application
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "2", "--timeout", "120", "main:app"]
"""
        
        with open("Dockerfile", 'w') as f:
            f.write(dockerfile_content)
        print("✅ Dockerfile created")
    
    def create_dockerignore(self):
        """Create .dockerignore file"""
        dockerignore_content = """# Python
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
venv/
env/
.env

# Development files
.git/
.gitignore
README.md
DOWNLOAD_*.md
*.md

# IDE
.vscode/
.idea/

# Logs
*.log
logs/

# Database (will be created in container)
instance/*.db

# OS
.DS_Store
Thumbs.db

# Development scripts
setup_local.py
run_local.py
deploy_local.py
start_chatbot.*
"""
        
        with open(".dockerignore", 'w') as f:
            f.write(dockerignore_content)
        print("✅ .dockerignore created")
    
    def create_docker_compose(self):
        """Create docker-compose.yml for easy deployment"""
        compose_content = f"""version: '3.8'

services:
  chatbot:
    build: .
    image: {self.image_name}
    container_name: {self.container_name}
    ports:
      - "{self.port}:{self.port}"
    environment:
      - GEMINI_API_KEY=${{GEMINI_API_KEY}}
      - SESSION_SECRET=${{SESSION_SECRET:-dev-secret-key}}
      - DATABASE_URL=sqlite:///instance/chatbot.db
      - FLASK_ENV=production
    volumes:
      - chatbot_data:/app/instance
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:{self.port}/"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

volumes:
  chatbot_data:
    driver: local
"""
        
        with open("docker-compose.yml", 'w') as f:
            f.write(compose_content)
        print("✅ docker-compose.yml created")
    
    def create_env_template(self):
        """Create .env.docker template"""
        env_content = """# Docker Environment Configuration
# Copy this to .env and add your actual values

GEMINI_API_KEY=your_gemini_api_key_here
SESSION_SECRET=your-super-secret-key-for-production
"""
        
        with open(".env.docker", 'w') as f:
            f.write(env_content)
        print("✅ .env.docker template created")
    
    def build_image(self):
        """Build Docker image"""
        print("🔨 Building Docker image...")
        result = subprocess.run([
            "docker", "build", 
            "-t", self.image_name,
            "."
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Docker image built successfully")
            return True
        else:
            print(f"❌ Failed to build Docker image: {result.stderr}")
            return False
    
    def run_container(self):
        """Run Docker container"""
        print("🚀 Starting Docker container...")
        
        # Stop existing container if running
        subprocess.run(["docker", "stop", self.container_name], 
                      capture_output=True)
        subprocess.run(["docker", "rm", self.container_name], 
                      capture_output=True)
        
        # Run new container
        cmd = [
            "docker", "run",
            "-d",
            "--name", self.container_name,
            "-p", f"{self.port}:{self.port}",
            "--env-file", ".env",
            self.image_name
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✅ Container started successfully")
            print(f"🌐 Access at: http://localhost:{self.port}")
            return True
        else:
            print(f"❌ Failed to start container: {result.stderr}")
            return False
    
    def deploy_with_compose(self):
        """Deploy using docker-compose"""
        print("🚀 Deploying with docker-compose...")
        
        if not Path(".env").exists():
            print("⚠️  No .env file found. Copy .env.docker to .env and add your API key")
            return False
        
        result = subprocess.run([
            "docker-compose", "up", "-d", "--build"
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Deployed successfully with docker-compose")
            print(f"🌐 Access at: http://localhost:{self.port}")
            return True
        else:
            print(f"❌ Deployment failed: {result.stderr}")
            return False
    
    def create_deployment_scripts(self):
        """Create helper scripts for Docker deployment"""
        
        # Build script
        build_script = f"""#!/bin/bash
echo "Building {self.project_name}..."
docker build -t {self.image_name} .
echo "Build complete!"
"""
        with open("docker-build.sh", 'w') as f:
            f.write(build_script)
        os.chmod("docker-build.sh", 0o755)
        
        # Start script  
        start_script = f"""#!/bin/bash
echo "Starting {self.project_name}..."
docker-compose up -d
echo "Started! Access at http://localhost:{self.port}"
"""
        with open("docker-start.sh", 'w') as f:
            f.write(start_script)
        os.chmod("docker-start.sh", 0o755)
        
        # Stop script
        stop_script = f"""#!/bin/bash
echo "Stopping {self.project_name}..."
docker-compose down
echo "Stopped!"
"""
        with open("docker-stop.sh", 'w') as f:
            f.write(stop_script)
        os.chmod("docker-stop.sh", 0o755)
        
        print("✅ Docker helper scripts created")
    
    def deploy(self, method="compose"):
        """Main deployment method"""
        print("🐳 Docker Deployment for College Query Chatbot")
        print("=" * 50)
        
        # Create Docker files
        self.create_dockerfile()
        self.create_dockerignore()
        self.create_docker_compose()
        self.create_env_template()
        self.create_deployment_scripts()
        
        if method == "compose":
            return self.deploy_with_compose()
        else:
            return self.build_image() and self.run_container()

def main():
    deployment = DockerDeployment()
    
    # Check if Docker is available
    try:
        subprocess.run(["docker", "--version"], 
                      capture_output=True, check=True)
        print("✅ Docker detected")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("❌ Docker not found. Please install Docker first.")
        print("   Visit: https://docs.docker.com/get-docker/")
        sys.exit(1)
    
    # Deploy
    success = deployment.deploy()
    
    if success:
        print("\n🎉 Docker deployment completed!")
        print("📋 Next steps:")
        print("   1. Copy .env.docker to .env")
        print("   2. Add your Gemini API key to .env")
        print("   3. Run: docker-compose up -d")
        print(f"   4. Access: http://localhost:{deployment.port}")
    else:
        print("\n❌ Docker deployment failed")
        sys.exit(1)

if __name__ == "__main__":
    main()