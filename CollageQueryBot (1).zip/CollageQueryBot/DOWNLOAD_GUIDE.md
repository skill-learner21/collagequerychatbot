# How to Download and Run the College Query Chatbot Locally

## Quick Download Guide

### Method 1: Download All Files Individually

Copy these files from the Replit project to your local machine:

**Main Application Files:**
- `app.py` - Flask application setup
- `main.py` - Application entry point  
- `routes.py` - Web routes and API endpoints
- `models.py` - Database models
- `ai_service.py` - Google Gemini AI integration
- `web_scraper.py` - Website scraping functionality

**Frontend Files:**
- `templates/base.html` - Base HTML template
- `templates/index.html` - Main chat interface
- `static/css/style.css` - All styling and animations
- `static/js/chat.js` - JavaScript functionality

**Setup Files (I created these for you):**
- `README.md` - Complete setup instructions
- `local_requirements.txt` - Python dependencies
- `run_local.py` - Easy local runner
- `setup_local.py` - Automated setup script
- `.gitignore` - Git ignore file

### Method 2: Replit Download (if available)

1. Go to your Replit project
2. Click the three dots menu (⋯) 
3. Select "Download as zip"
4. Extract the zip file to your desired folder

## Quick Start (2 Minutes)

1. **Download all files** to a folder called `college-chatbot`

2. **Open in VS Code:**
   ```bash
   cd college-chatbot
   code .
   ```

3. **One-click setup:**
   ```bash
   python setup_local.py
   ```

4. **Get your Gemini API key:**
   - Visit: https://aistudio.google.com/app/apikey
   - Create an API key
   - Add it to the `.env` file that was created

5. **Run the app:**
   ```bash
   python run_local.py
   ```

6. **Open your browser:** http://localhost:5000

## Manual Setup (if automatic setup fails)

```bash
# Create virtual environment
python -m venv venv

# Activate it (Windows)
venv\Scripts\activate
# Or on macOS/Linux
source venv/bin/activate

# Install dependencies
pip install -r local_requirements.txt

# Create .env file and add your Gemini API key
echo "GEMINI_API_KEY=your_key_here" > .env

# Run the app
python run_local.py
```

## File Structure After Download

```
college-chatbot/
├── app.py                 # Flask app configuration
├── main.py               # Main entry point
├── routes.py             # API routes
├── models.py             # Database models
├── ai_service.py         # Gemini AI integration
├── web_scraper.py        # Website scraping
├── run_local.py          # Local development runner
├── setup_local.py        # Automated setup
├── local_requirements.txt # Dependencies
├── README.md             # Full documentation
├── .env                  # Environment variables (you create this)
├── .gitignore           # Git ignore file
├── templates/
│   ├── base.html        # Base template
│   └── index.html       # Main interface
├── static/
│   ├── css/
│   │   └── style.css    # All styles
│   └── js/
│       └── chat.js      # JavaScript
└── instance/
    └── chatbot.db       # SQLite database (auto-created)
```

## What You Need

1. **Python 3.9+** - Download from python.org
2. **Gemini API Key** - Free from Google AI Studio
3. **VS Code** - Recommended editor
4. **Internet connection** - For AI API calls and web scraping

## Features That Work Locally

✅ **Everything works exactly the same as on Replit:**
- Google Gemini AI responses
- Website scraping and analysis  
- Modern responsive UI
- Chat history and sessions  
- Mobile-friendly design
- All animations and styling

## Common Issues & Solutions

**Import Errors:**
```bash
pip install --upgrade pip
pip install -r local_requirements.txt
```

**Database Issues:**
- Delete `instance/chatbot.db` to reset
- Make sure the `instance/` folder exists

**API Key Issues:**
- Double-check your `.env` file format
- Verify the API key at Google AI Studio
- Make sure there are no extra spaces

**Port Already in Use:**
- Change port in `run_local.py` (line with `port=5000`)
- Or kill the process using port 5000

## Need Help?

1. Check the console for error messages
2. Read the full `README.md` for detailed instructions  
3. Verify all files were downloaded correctly
4. Make sure your Gemini API key is valid

The app should work identically to the Replit version once set up correctly!