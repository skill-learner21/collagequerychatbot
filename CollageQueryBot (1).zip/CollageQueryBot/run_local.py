#!/usr/bin/env python3
"""
Local development runner for College Query Chatbot
Run this file to start the application locally in VS Code
"""

import os
import sys
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import and run the Flask app
from main import app

if __name__ == '__main__':
    # Set default environment variables if not present
    if not os.environ.get('SESSION_SECRET'):
        os.environ['SESSION_SECRET'] = 'dev-secret-key-change-in-production'
    
    if not os.environ.get('DATABASE_URL'):
        os.environ['DATABASE_URL'] = 'sqlite:///instance/chatbot.db'
    
    # Check for required API key
    if not os.environ.get('GEMINI_API_KEY'):
        print("⚠️  WARNING: GEMINI_API_KEY not found!")
        print("Please create a .env file with your Gemini API key:")
        print("GEMINI_API_KEY=your_api_key_here")
        print("\nGet your API key from: https://aistudio.google.com/app/apikey")
        print("The app will still run but AI responses won't work without the API key.\n")
    
    print("🚀 Starting College Query Chatbot...")
    print("📱 Access the app at: http://localhost:5000")
    print("🛑 Press Ctrl+C to stop the server")
    
    # Run the Flask development server
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        use_reloader=True
    )