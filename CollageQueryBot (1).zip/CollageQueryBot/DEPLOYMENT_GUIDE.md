# 🚀 One-Click Deployment Guide for College Query Chatbot

## Overview

This project includes a comprehensive one-click deployment system that supports multiple deployment methods. Choose the one that best fits your needs:

## 🎯 Quick Start (30 seconds)

```bash
# Download all files to your computer
# Open terminal in the project folder
python deploy.py
```

That's it! The interactive menu will guide you through the rest.

## 📋 Deployment Options

### 1. 🖥️ Local Development Setup (Recommended for VS Code)

**What it does:**
- Creates isolated virtual environment
- Installs all Python dependencies automatically
- Creates platform-specific startup scripts
- Sets up proper project structure
- Creates `.env` file template

**How to use:**
```bash
python deploy.py
# Choose option 1
```

**Perfect for:**
- VS Code development
- Learning and experimentation
- Custom modifications
- Full control over the environment

---

### 2. 🐳 Docker Deployment (Recommended for Production)

**What it does:**
- Creates optimized Dockerfile
- Sets up docker-compose configuration
- Includes health checks and restart policies
- Creates helper scripts for easy management
- Production-ready scaling

**Requirements:**
- Docker installed on your system

**How to use:**
```bash
python deploy.py
# Choose option 2
```

**Perfect for:**
- Production deployments
- Consistent environments
- Easy scaling
- Server deployments

---

### 3. ☁️ Cloud Deployment Files

**Supported Platforms:**
- **Heroku** - Easy deployment with PostgreSQL
- **Railway** - Modern cloud platform
- **Vercel** - Serverless deployment
- **Render** - Simple cloud hosting

**What it does:**
- Creates platform-specific configuration files
- Sets up environment variables
- Configures databases automatically
- Provides deployment guides

**How to use:**
```bash
python deploy.py
# Choose option 3
# Select your preferred platform
```

---

### 4. 🚀 Quick Local Start (Fastest for Testing)

**What it does:**
- Uses your system Python
- Installs packages globally
- Creates minimal configuration
- Starts immediately

**How to use:**
```bash
python deploy.py
# Choose option 4
```

**Perfect for:**
- Quick demos
- Testing the chatbot
- Immediate results

---

### 5. 📖 Deployment Status Check

**What it does:**
- Checks current setup status
- Identifies missing components
- Provides troubleshooting suggestions
- Shows configuration health

**How to use:**
```bash
python deploy.py
# Choose option 5
```

## 🔧 Manual Deployment (Advanced)

If you prefer manual control, you can run individual deployment scripts:

```bash
# Local development
python deploy_local.py

# Docker deployment  
python deploy_docker.py

# Cloud deployment files
python deploy_cloud.py heroku
python deploy_cloud.py railway
python deploy_cloud.py all
```

## 📝 Environment Configuration

After deployment, you'll need to set up your environment variables:

### Required Variables:
```env
GEMINI_API_KEY=your_actual_api_key_here
```

### Optional Variables:
```env
SESSION_SECRET=your-secure-secret-key
DATABASE_URL=sqlite:///instance/chatbot.db
FLASK_ENV=development
PORT=5000
```

### Getting Your Gemini API Key:
1. Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy and paste into your `.env` file

## 🛠️ Troubleshooting

### Common Issues:

**Python Version Error:**
- Ensure Python 3.9+ is installed
- Check with: `python --version`

**Permission Errors:**
- On Linux/Mac: `chmod +x *.py`
- Run as administrator on Windows if needed

**Package Installation Fails:**
- Check internet connection
- Try: `pip install --upgrade pip`
- Use: `python -m pip install -r local_requirements.txt`

**Docker Issues:**
- Ensure Docker is installed and running
- Check with: `docker --version`

**API Key Problems:**
- Verify your API key at Google AI Studio
- Check for extra spaces in `.env` file
- Ensure file is named exactly `.env`

### Getting Help:

1. **Check deployment status:** Run option 5 in the deployment menu
2. **View logs:** Check terminal output for error messages
3. **Reset setup:** Delete `venv/` folder and run deployment again
4. **Test components:** Use the status check to identify issues

## 🎯 Deployment Recommendations

### For Beginners:
Start with **Option 1 (Local Development)** - it's the most straightforward and gives you full control.

### For Production:
Use **Option 2 (Docker)** for consistent, scalable deployments.

### For Cloud Hosting:
Use **Option 3 (Cloud Deployment)** with Heroku or Railway for hassle-free hosting.

### For Quick Testing:
Use **Option 4 (Quick Start)** when you just want to see the chatbot in action.

## 📊 Feature Comparison

| Feature | Local Dev | Docker | Cloud | Quick Start |
|---------|-----------|---------|-------|-------------|
| Setup Time | 2-3 min | 3-5 min | 5-10 min | 30 seconds |
| Production Ready | ⚠️ | ✅ | ✅ | ❌ |
| Isolation | ✅ | ✅ | ✅ | ❌ |
| Customization | ✅ | ⚠️ | ❌ | ✅ |
| Scaling | ❌ | ✅ | ✅ | ❌ |
| Cost | Free | Free | Variable | Free |

## 🚀 Success! What's Next?

After successful deployment:

1. **Access your chatbot** at `http://localhost:5000`
2. **Add college websites** using the sidebar to enhance AI responses
3. **Start asking questions** about colleges, admissions, programs, etc.
4. **Customize the UI** by editing `static/css/style.css`
5. **Add new features** by modifying the Python files

Your AI-powered college query chatbot is now ready to help students with their college questions!