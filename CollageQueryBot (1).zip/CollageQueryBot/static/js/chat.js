// Chat functionality
class CollegeChatbot {
    constructor() {
        this.messageInput = document.getElementById('messageInput');
        this.sendBtn = document.getElementById('sendBtn');
        this.chatMessages = document.getElementById('chatMessages');
        this.loadingIndicator = document.getElementById('loadingIndicator');
        this.websiteUrl = document.getElementById('websiteUrl');
        this.scrapeBtn = document.getElementById('scrapeBtn');
        this.websiteList = document.getElementById('websiteList');
        this.clearSessionBtn = document.getElementById('clearSessionBtn');
        
        this.initializeEventListeners();
        this.loadWebsites();
    }
    
    initializeEventListeners() {
        // Send message on button click
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        
        // Send message on Enter key press
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Scrape website on button click
        this.scrapeBtn.addEventListener('click', () => this.scrapeWebsite());
        
        // Scrape website on Enter key press
        this.websiteUrl.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.scrapeWebsite();
            }
        });
        
        // Clear session
        this.clearSessionBtn.addEventListener('click', () => this.clearSession());
    }
    
    async sendMessage() {
        const message = this.messageInput.value.trim();
        
        if (!message) {
            this.showError('Please enter a message');
            return;
        }
        
        // Disable input and show loading
        this.setLoading(true);
        
        // Add user message to chat
        this.addMessageToChat(message, true);
        
        // Clear input
        this.messageInput.value = '';
        
        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: message })
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to get response');
            }
            
            // Add bot response to chat
            this.addMessageToChat(data.response, false);
            
        } catch (error) {
            console.error('Error sending message:', error);
            this.showError(error.message || 'Failed to send message. Please try again.');
            this.addMessageToChat('Sorry, I encountered an error. Please try again.', false);
        } finally {
            this.setLoading(false);
        }
    }
    
    addMessageToChat(message, isUser) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-message';
        
        if (isUser) {
            messageDiv.innerHTML = `
                <div class="d-flex justify-content-end mb-3">
                    <div class="user-message px-4 py-3 max-width-70">
                        ${this.escapeHtml(message)}
                    </div>
                </div>
            `;
        } else {
            messageDiv.innerHTML = `
                <div class="d-flex justify-content-start mb-4">
                    <div class="me-2">
                        <div class="bg-primary rounded-circle p-2" style="background: var(--pu-gradient) !important; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-robot text-white small"></i>
                        </div>
                    </div>
                    <div class="bot-message px-4 py-3 max-width-70">
                        ${this.formatBotMessage(message)}
                    </div>
                </div>
            `;
        }
        
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }
    
    formatBotMessage(message) {
        // Simple formatting for bot messages
        return this.escapeHtml(message)
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
    
    setLoading(loading) {
        if (loading) {
            this.sendBtn.disabled = true;
            this.messageInput.disabled = true;
            this.loadingIndicator.style.display = 'block';
        } else {
            this.sendBtn.disabled = false;
            this.messageInput.disabled = false;
            this.loadingIndicator.style.display = 'none';
            this.messageInput.focus();
        }
    }
    
    async scrapeWebsite() {
        const url = this.websiteUrl.value.trim();
        
        if (!url) {
            this.showError('Please enter a website URL');
            return;
        }
        
        // Basic URL validation
        try {
            new URL(url);
        } catch {
            this.showError('Please enter a valid URL');
            return;
        }
        
        // Disable scrape button
        this.scrapeBtn.disabled = true;
        this.scrapeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        
        try {
            const response = await fetch('/scrape', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url: url })
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to scrape website');
            }
            
            this.showSuccess(data.message);
            this.websiteUrl.value = '';
            this.loadWebsites();
            
        } catch (error) {
            console.error('Error scraping website:', error);
            this.showError(error.message || 'Failed to scrape website. Please try again.');
        } finally {
            this.scrapeBtn.disabled = false;
            this.scrapeBtn.innerHTML = '<i class="fas fa-plus"></i>';
        }
    }
    
    async loadWebsites() {
        try {
            const response = await fetch('/websites');
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to load websites');
            }
            
            this.updateWebsiteList(data.websites);
            
        } catch (error) {
            console.error('Error loading websites:', error);
        }
    }
    
    updateWebsiteList(websites) {
        if (!websites || websites.length === 0) {
            this.websiteList.innerHTML = `
                <div class="text-muted small">
                    <i class="fas fa-info-circle me-1"></i>
                    No websites added yet
                </div>
            `;
            return;
        }
        
        this.websiteList.innerHTML = websites.map(site => `
            <div class="website-item">
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <div class="small fw-bold text-truncate" title="${this.escapeHtml(site.url)}">
                            ${this.escapeHtml(site.title)}
                        </div>
                        <div class="text-muted" style="font-size: 0.75rem;">
                            ${site.content_length} characters
                        </div>
                    </div>
                    <i class="fas fa-check-circle text-success ms-2"></i>
                </div>
            </div>
        `).join('');
    }
    
    async clearSession() {
        if (!confirm('Are you sure you want to clear the chat history?')) {
            return;
        }
        
        try {
            const response = await fetch('/clear-session', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to clear session');
            }
            
            // Reload the page to show cleared state
            window.location.reload();
            
        } catch (error) {
            console.error('Error clearing session:', error);
            this.showError(error.message || 'Failed to clear session. Please try again.');
        }
    }
    
    showError(message) {
        const errorToast = document.getElementById('errorToast');
        const errorMessage = document.getElementById('errorMessage');
        
        errorMessage.textContent = message;
        const toast = new bootstrap.Toast(errorToast);
        toast.show();
    }
    
    showSuccess(message) {
        const successToast = document.getElementById('successToast');
        const successMessage = document.getElementById('successMessage');
        
        successMessage.textContent = message;
        const toast = new bootstrap.Toast(successToast);
        toast.show();
    }
}

// Initialize the chatbot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new CollegeChatbot();
});
