#!/usr/bin/env python3
"""
Master One-Click Deployment Script for College Query Chatbot
Supports local, Docker, and cloud deployments with interactive menu
"""

import os
import sys
import subprocess
from pathlib import Path

class MasterDeployment:
    def __init__(self):
        self.project_name = "College Query Chatbot"
        self.version = "1.0.0"
        
    def print_banner(self):
        """Display deployment banner"""
        print("=" * 70)
        print(f"🎓 {self.project_name} - One-Click Deployment System")
        print(f"    Version {self.version}")
        print("=" * 70)
        print()
    
    def print_menu(self):
        """Display deployment options menu"""
        print("📋 Available Deployment Options:")
        print()
        print("1. 🖥️  Local Development Setup")
        print("   • Creates virtual environment")
        print("   • Installs all dependencies")
        print("   • Creates startup scripts")
        print("   • Perfect for VS Code development")
        print()
        print("2. 🐳 Docker Deployment")
        print("   • Creates Docker containers")
        print("   • Includes docker-compose setup")
        print("   • Production-ready configuration")
        print("   • Easy scaling and management")
        print()
        print("3. ☁️  Cloud Deployment Files")
        print("   • Heroku, Railway, Vercel, Render")
        print("   • Creates platform-specific configs")
        print("   • Deployment guides included")
        print("   • One-click cloud deployment")
        print()
        print("4. 🚀 Quick Local Start")
        print("   • Minimal setup for immediate testing")
        print("   • Uses system Python")
        print("   • Good for quick demos")
        print()
        print("5. 📖 Show Deployment Status")
        print("   • Check what's already set up")
        print("   • View configuration status")
        print("   • Troubleshooting help")
        print()
        print("0. ❌ Exit")
        print()
    
    def check_requirements(self):
        """Check if required files exist"""
        required_files = [
            "main.py", "app.py", "routes.py", "models.py", 
            "ai_service.py", "web_scraper.py", "local_requirements.txt"
        ]
        
        missing_files = []
        for file in required_files:
            if not Path(file).exists():
                missing_files.append(file)
        
        if missing_files:
            print("❌ Missing required files:")
            for file in missing_files:
                print(f"   • {file}")
            print()
            print("Please ensure all project files are in the current directory.")
            return False
        
        print("✅ All required files found")
        return True
    
    def run_local_deployment(self):
        """Run local development deployment"""
        print("🖥️  Starting Local Development Setup...")
        print("-" * 40)
        
        try:
            result = subprocess.run([sys.executable, "deploy_local.py"], 
                                  check=False, capture_output=False)
            return result.returncode == 0
        except FileNotFoundError:
            print("❌ deploy_local.py not found")
            return False
        except Exception as e:
            print(f"❌ Error running local deployment: {str(e)}")
            return False
    
    def run_docker_deployment(self):
        """Run Docker deployment"""
        print("🐳 Starting Docker Deployment...")
        print("-" * 40)
        
        # Check if Docker is available
        try:
            subprocess.run(["docker", "--version"], 
                          capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("❌ Docker not found. Please install Docker first.")
            print("   Visit: https://docs.docker.com/get-docker/")
            return False
        
        try:
            result = subprocess.run([sys.executable, "deploy_docker.py"], 
                                  check=False, capture_output=False)
            return result.returncode == 0
        except FileNotFoundError:
            print("❌ deploy_docker.py not found")
            return False
        except Exception as e:
            print(f"❌ Error running Docker deployment: {str(e)}")
            return False
    
    def run_cloud_deployment(self):
        """Run cloud deployment setup"""
        print("☁️  Starting Cloud Deployment Setup...")
        print("-" * 40)
        
        print("Available platforms:")
        print("1. Heroku")
        print("2. Railway") 
        print("3. Vercel")
        print("4. Render")
        print("5. All platforms")
        
        choice = input("\nChoose platform (1-5): ").strip()
        
        platform_map = {
            "1": "heroku",
            "2": "railway", 
            "3": "vercel",
            "4": "render",
            "5": "all"
        }
        
        platform = platform_map.get(choice, "all")
        
        try:
            result = subprocess.run([sys.executable, "deploy_cloud.py", platform], 
                                  check=False, capture_output=False)
            return result.returncode == 0
        except FileNotFoundError:
            print("❌ deploy_cloud.py not found")
            return False
        except Exception as e:
            print(f"❌ Error running cloud deployment: {str(e)}")
            return False
    
    def quick_local_start(self):
        """Quick local start without virtual environment"""
        print("🚀 Quick Local Start...")
        print("-" * 40)
        
        # Check if requirements are installed
        try:
            import flask
            import google.genai
            import trafilatura
            print("✅ Required packages detected")
        except ImportError as e:
            print(f"❌ Missing package: {str(e)}")
            print("Installing required packages...")
            result = subprocess.run([
                sys.executable, "-m", "pip", "install", "-r", "local_requirements.txt"
            ], capture_output=True)
            
            if result.returncode != 0:
                print("❌ Failed to install packages")
                return False
        
        # Check for .env file
        if not Path(".env").exists():
            print("⚠️  No .env file found. Creating one...")
            env_content = """GEMINI_API_KEY=your_gemini_api_key_here
SESSION_SECRET=dev-secret-key
DATABASE_URL=sqlite:///instance/chatbot.db
"""
            with open(".env", 'w') as f:
                f.write(env_content)
            print("✅ .env file created - please add your Gemini API key")
        
        # Create instance directory
        Path("instance").mkdir(exist_ok=True)
        
        print("🚀 Starting application...")
        try:
            subprocess.run([sys.executable, "run_local.py"])
        except KeyboardInterrupt:
            print("\n⏹️  Application stopped")
        
        return True
    
    def show_deployment_status(self):
        """Show current deployment status"""
        print("📊 Deployment Status Check")
        print("-" * 40)
        
        # Check virtual environment
        venv_exists = Path("venv").exists()
        print(f"Virtual Environment: {'✅ Exists' if venv_exists else '❌ Not found'}")
        
        # Check .env file
        env_exists = Path(".env").exists()
        print(f"Environment File: {'✅ Exists' if env_exists else '❌ Not found'}")
        
        if env_exists:
            # Check if API key is set
            try:
                with open(".env", 'r') as f:
                    content = f.read()
                    if "your_gemini_api_key_here" in content:
                        print("   ⚠️  Please update your Gemini API key in .env")
                    else:
                        print("   ✅ API key appears to be set")
            except Exception:
                pass
        
        # Check Docker files
        docker_files = ["Dockerfile", "docker-compose.yml"]
        docker_ready = all(Path(f).exists() for f in docker_files)
        print(f"Docker Setup: {'✅ Ready' if docker_ready else '❌ Not configured'}")
        
        # Check cloud deployment files
        cloud_files = ["Procfile", "app.json", "railway.json", "vercel.json"]
        cloud_ready = any(Path(f).exists() for f in cloud_files)
        print(f"Cloud Deployment: {'✅ Configured' if cloud_ready else '❌ Not configured'}")
        
        # Check instance directory
        instance_exists = Path("instance").exists()
        print(f"Database Directory: {'✅ Exists' if instance_exists else '❌ Not found'}")
        
        # Quick fix suggestions
        print("\n💡 Quick Fixes:")
        if not env_exists:
            print("   • Run option 1 or 4 to create .env file")
        if not venv_exists:
            print("   • Run option 1 for full local setup")
        if not docker_ready:
            print("   • Run option 2 for Docker setup")
        if not cloud_ready:
            print("   • Run option 3 for cloud deployment files")
        
        return True
    
    def run_deployment(self):
        """Main deployment orchestrator"""
        self.print_banner()
        
        # Check requirements first
        if not self.check_requirements():
            return False
        
        while True:
            self.print_menu()
            choice = input("Choose deployment option (0-5): ").strip()
            
            if choice == "0":
                print("👋 Goodbye!")
                break
            elif choice == "1":
                success = self.run_local_deployment()
            elif choice == "2":
                success = self.run_docker_deployment()
            elif choice == "3":
                success = self.run_cloud_deployment()
            elif choice == "4":
                success = self.quick_local_start()
            elif choice == "5":
                success = self.show_deployment_status()
            else:
                print("❌ Invalid choice. Please select 0-5.")
                continue
            
            if success:
                print(f"\n✅ Deployment option {choice} completed successfully!")
            else:
                print(f"\n❌ Deployment option {choice} failed.")
            
            input("\nPress Enter to continue...")
            print("\n" * 2)  # Clear screen spacing
        
        return True

def main():
    """Main entry point"""
    deployment = MasterDeployment()
    
    try:
        deployment.run_deployment()
        sys.exit(0)
    except KeyboardInterrupt:
        print(f"\n👋 Deployment cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()