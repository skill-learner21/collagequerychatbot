import trafilatura
import logging
import requests
from urllib.parse import urlparse
import time

def get_website_text_content(url: str) -> str:
    """
    Enhanced website scraping that extracts clean, structured content
    optimized for college information analysis.
    """
    try:
        # Validate URL
        parsed_url = urlparse(url)
        if not parsed_url.scheme:
            url = "https://" + url  # Add https if missing
            parsed_url = urlparse(url)
        
        if not parsed_url.netloc:
            raise ValueError("Invalid URL format")
        
        # Enhanced extraction settings for better content quality with better error handling
        logging.info(f"Attempting to scrape URL: {url}")
        
        # Use requests with timeout and proper headers, then pass to trafilatura
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        try:
            # First, try to get the content using requests with timeout
            response = requests.get(url, headers=headers, timeout=15, verify=False)
            response.raise_for_status()
            
            # Now use trafilatura to extract text from the HTML content
            downloaded = response.text
            
        except requests.exceptions.Timeout:
            logging.error(f"Timeout while fetching {url}")
            raise Exception("Website took too long to respond. Please try again.")
        except requests.exceptions.ConnectionError:
            logging.error(f"Connection error for {url}")
            raise Exception("Could not connect to the website. Please check the URL.")
        except requests.exceptions.RequestException as e:
            logging.error(f"Request error for {url}: {str(e)}")
            # Try trafilatura's built-in fetcher as fallback
            downloaded = trafilatura.fetch_url(url)
        
        if not downloaded:
            raise Exception("Failed to download content from URL")
        
        # Extract with enhanced settings for educational content
        text = trafilatura.extract(
            downloaded,
            include_comments=False,
            include_tables=True,  # Important for fee structures, course lists
            include_links=False,
            favor_precision=True,  # Better quality extraction
            favor_recall=False
        )
        
        if not text:
            # Fallback extraction if first attempt fails
            text = trafilatura.extract(downloaded, favor_recall=True)
        
        if not text:
            raise Exception("No text content could be extracted from the page")
        
        # Clean and structure the extracted text
        cleaned_text = clean_college_content(text)
        
        return cleaned_text
    
    except Exception as e:
        logging.error(f"Error scraping {url}: {str(e)}")
        raise Exception(f"Failed to scrape website: {str(e)}")

def clean_college_content(text: str) -> str:
    """Clean and structure college website content for better analysis"""
    try:
        # Remove excessive whitespace and normalize line breaks
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        # Filter out very short lines that don't contain useful information
        useful_lines = []
        for line in lines:
            # Keep lines that are substantial and likely contain useful info
            if (len(line) > 15 and 
                not line.lower().startswith(('skip to', 'skip', 'menu', 'navigation')) and
                not all(c in '|-+=[]{}()' for c in line)):
                useful_lines.append(line)
        
        # Join lines with proper spacing
        cleaned_text = '\n'.join(useful_lines)
        
        # Limit total length to prevent overwhelming the analysis
        if len(cleaned_text) > 15000:  # ~15KB limit
            cleaned_text = cleaned_text[:15000] + "..."
        
        return cleaned_text
        
    except Exception as e:
        logging.error(f"Error cleaning content: {str(e)}")
        return text  # Return original if cleaning fails

def is_valid_college_url(url: str) -> bool:
    """
    Basic validation to check if URL might be a college website
    """
    try:
        parsed_url = urlparse(url)
        domain = parsed_url.netloc.lower()
        
        # Common indicators of educational institutions
        edu_indicators = ['.edu', 'university', 'college', 'school', 'academy']
        
        return any(indicator in domain for indicator in edu_indicators)
    
    except:
        return False
