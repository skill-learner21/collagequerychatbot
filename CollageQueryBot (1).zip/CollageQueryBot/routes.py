import uuid
import logging
from flask import render_template, request, jsonify, session
from app import app, db
from models import ChatSession, ChatMessage, WebsiteData
from ai_service import get_ai_response
from web_scraper import get_website_text_content

@app.route('/')
def index():
    """Main chat interface"""
    # Create or get session ID
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
        
        # Create new chat session in database
        chat_session = ChatSession()
        chat_session.session_id = session['session_id']
        db.session.add(chat_session)
        db.session.commit()
    
    # Get chat history for this session
    chat_messages = ChatMessage.query.filter_by(session_id=session['session_id']).order_by(ChatMessage.timestamp).all()
    
    return render_template('index.html', messages=chat_messages)

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages and return AI responses"""
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Create session if it doesn't exist
        session_id = session.get('session_id')
        if not session_id:
            session_id = str(uuid.uuid4())
            session['session_id'] = session_id
            
            # Create new chat session in database
            chat_session = ChatSession()
            chat_session.session_id = session_id
            db.session.add(chat_session)
            db.session.commit()
            logging.info(f"Created new session: {session_id}")
        
        # Get previous messages for context
        previous_messages = ChatMessage.query.filter_by(session_id=session_id).order_by(ChatMessage.timestamp.desc()).limit(5).all()
        
        # Prepare context from previous messages
        context = []
        for msg in reversed(previous_messages):
            context.append(f"User: {msg.message}")
            context.append(f"Assistant: {msg.response}")
        
        # Get AI response
        ai_response = get_ai_response(user_message, context)
        
        # Save message and response to database
        chat_message = ChatMessage()
        chat_message.session_id = session_id
        chat_message.message = user_message
        chat_message.response = ai_response
        db.session.add(chat_message)
        db.session.commit()
        
        return jsonify({
            'response': ai_response,
            'timestamp': chat_message.timestamp.isoformat()
        })
        
    except Exception as e:
        logging.error(f"Error in chat route: {str(e)}")
        return jsonify({'error': 'Failed to process message. Please try again.'}), 500

@app.route('/scrape', methods=['POST'])
def scrape_website():
    """Scrape website data and store it"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        # Check if we already have this URL
        existing_data = WebsiteData.query.filter_by(url=url).first()
        
        # Scrape the website
        content = get_website_text_content(url)
        
        if not content:
            return jsonify({'error': 'Failed to extract content from the URL'}), 400
        
        if existing_data:
            # Update existing data
            existing_data.content = content
            existing_data.last_updated = db.func.now()
        else:
            # Create new website data entry
            website_data = WebsiteData()
            website_data.url = url
            website_data.content = content
            db.session.add(website_data)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Website data scraped and stored successfully',
            'content_length': len(content)
        })
        
    except Exception as e:
        logging.error(f"Error in scrape route: {str(e)}")
        return jsonify({'error': 'Failed to scrape website. Please check the URL and try again.'}), 500

@app.route('/websites')
def list_websites():
    """Get list of scraped websites"""
    try:
        websites = WebsiteData.query.order_by(WebsiteData.last_updated.desc()).all()
        
        website_list = []
        for site in websites:
            website_list.append({
                'id': site.id,
                'url': site.url,
                'title': site.title or site.url,
                'content_length': len(site.content) if site.content else 0,
                'last_updated': site.last_updated.isoformat()
            })
        
        return jsonify({'websites': website_list})
        
    except Exception as e:
        logging.error(f"Error in list_websites route: {str(e)}")
        return jsonify({'error': 'Failed to retrieve website list'}), 500

@app.route('/clear-session', methods=['POST'])
def clear_session():
    """Clear current chat session"""
    try:
        session_id = session.get('session_id')
        if session_id:
            # Delete all messages for this session
            ChatMessage.query.filter_by(session_id=session_id).delete()
            # Delete the session
            ChatSession.query.filter_by(session_id=session_id).delete()
            db.session.commit()
            
            # Clear session
            session.pop('session_id', None)
        
        return jsonify({'message': 'Session cleared successfully'})
        
    except Exception as e:
        logging.error(f"Error in clear_session route: {str(e)}")
        return jsonify({'error': 'Failed to clear session'}), 500
