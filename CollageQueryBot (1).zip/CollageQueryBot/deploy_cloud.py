#!/usr/bin/env python3
"""
Cloud Deployment Script for College Query Chatbot
Supports deployment to multiple cloud platforms
"""

import os
import sys
import subprocess
import json
import yaml
from pathlib import Path

class CloudDeployment:
    def __init__(self):
        self.project_name = "college-query-chatbot"
        self.app_name = "college-chatbot"
        
    def create_heroku_files(self):
        """Create Heroku deployment files"""
        
        # Procfile
        procfile_content = "web: gunicorn --bind 0.0.0.0:$PORT main:app"
        with open("Procfile", 'w') as f:
            f.write(procfile_content)
        
        # runtime.txt
        runtime_content = "python-3.11.0"
        with open("runtime.txt", 'w') as f:
            f.write(runtime_content)
        
        # app.json for Heroku app metadata
        app_json = {
            "name": "College Query Chatbot",
            "description": "AI-powered college information chatbot with Google Gemini",
            "repository": "https://github.com/your-username/college-query-chatbot",
            "keywords": ["python", "flask", "ai", "chatbot", "education"],
            "env": {
                "GEMINI_API_KEY": {
                    "description": "Google Gemini API key from AI Studio",
                    "required": True
                },
                "SESSION_SECRET": {
                    "description": "Secret key for Flask sessions",
                    "generator": "secret"
                },
                "DATABASE_URL": {
                    "description": "Database URL (automatically provided by Heroku Postgres)",
                    "required": False
                }
            },
            "addons": [
                "heroku-postgresql:mini"
            ],
            "buildpacks": [
                {
                    "url": "heroku/python"
                }
            ]
        }
        
        with open("app.json", 'w') as f:
            json.dump(app_json, f, indent=2)
        
        print("✅ Heroku deployment files created")
    
    def create_railway_files(self):
        """Create Railway deployment files"""
        
        # railway.json
        railway_config = {
            "build": {
                "builder": "NIXPACKS"
            },
            "deploy": {
                "startCommand": "gunicorn --bind 0.0.0.0:$PORT main:app",
                "healthcheckPath": "/",
                "healthcheckTimeout": 100,
                "restartPolicyType": "ON_FAILURE",
                "restartPolicyMaxRetries": 10
            }
        }
        
        with open("railway.json", 'w') as f:
            json.dump(railway_config, f, indent=2)
        
        print("✅ Railway deployment files created")
    
    def create_vercel_files(self):
        """Create Vercel deployment files"""
        
        # vercel.json
        vercel_config = {
            "version": 2,
            "builds": [
                {
                    "src": "main.py",
                    "use": "@vercel/python"
                }
            ],
            "routes": [
                {
                    "src": "/(.*)",
                    "dest": "main.py"
                }
            ],
            "env": {
                "GEMINI_API_KEY": "@gemini_api_key",
                "SESSION_SECRET": "@session_secret"
            }
        }
        
        with open("vercel.json", 'w') as f:
            json.dump(vercel_config, f, indent=2)
        
        print("✅ Vercel deployment files created")
    
    def create_render_files(self):
        """Create Render deployment files"""
        
        # render.yaml
        render_config = {
            "services": [
                {
                    "type": "web",
                    "name": self.app_name,
                    "env": "python",
                    "buildCommand": "pip install -r local_requirements.txt",
                    "startCommand": "gunicorn --bind 0.0.0.0:$PORT main:app",
                    "envVars": [
                        {
                            "key": "GEMINI_API_KEY",
                            "sync": False
                        },
                        {
                            "key": "SESSION_SECRET",
                            "generateValue": True
                        },
                        {
                            "key": "DATABASE_URL",
                            "fromDatabase": {
                                "name": f"{self.app_name}-db",
                                "property": "connectionString"
                            }
                        }
                    ]
                }
            ],
            "databases": [
                {
                    "name": f"{self.app_name}-db",
                    "databaseName": "chatbot",
                    "user": "chatbot_user"
                }
            ]
        }
        
        with open("render.yaml", 'w') as f:
            yaml.dump(render_config, f, default_flow_style=False)
        
        print("✅ Render deployment files created")
    
    def create_deployment_guide(self):
        """Create comprehensive deployment guide"""
        
        guide_content = """# Cloud Deployment Guide

## Supported Platforms

### 1. Heroku (Recommended)
```bash
# Install Heroku CLI
# Create app
heroku create your-app-name

# Set environment variables
heroku config:set GEMINI_API_KEY=your_api_key

# Deploy
git push heroku main
```

### 2. Railway
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway link
railway up
```

### 3. Render
1. Connect your GitHub repository
2. Set environment variables in dashboard
3. Deploy automatically

### 4. Vercel
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

## Environment Variables Required
- GEMINI_API_KEY: Your Google Gemini API key
- SESSION_SECRET: Random secret for sessions
- DATABASE_URL: PostgreSQL connection (auto-provided on most platforms)
"""
        
        with open("CLOUD_DEPLOYMENT.md", 'w') as f:
            f.write(guide_content)
        
        print("✅ Cloud deployment guide created")
    
    def deploy_to_platform(self, platform):
        """Deploy to specific platform"""
        
        if platform == "heroku":
            self.create_heroku_files()
            print("🚀 Heroku files created. Run: git push heroku main")
        
        elif platform == "railway":
            self.create_railway_files()
            print("🚀 Railway files created. Run: railway up")
        
        elif platform == "vercel":
            self.create_vercel_files()
            print("🚀 Vercel files created. Run: vercel --prod")
        
        elif platform == "render":
            self.create_render_files()
            print("🚀 Render files created. Connect via GitHub")
        
        elif platform == "all":
            self.create_heroku_files()
            self.create_railway_files()
            self.create_vercel_files()
            self.create_render_files()
            print("🚀 All platform files created")
        
        self.create_deployment_guide()

def main():
    deployment = CloudDeployment()
    
    print("☁️  Cloud Deployment for College Query Chatbot")
    print("=" * 50)
    
    if len(sys.argv) > 1:
        platform = sys.argv[1].lower()
    else:
        print("Available platforms: heroku, railway, vercel, render, all")
        platform = input("Choose platform (or 'all'): ").lower()
    
    deployment.deploy_to_platform(platform)
    
    print("\n🎉 Cloud deployment files created!")
    print("📋 Next steps:")
    print("   1. Set up account on chosen platform")
    print("   2. Set GEMINI_API_KEY environment variable")
    print("   3. Follow platform-specific deployment steps")
    print("   4. See CLOUD_DEPLOYMENT.md for detailed instructions")

if __name__ == "__main__":
    main()