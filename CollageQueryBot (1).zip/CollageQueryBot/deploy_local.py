#!/usr/bin/env python3
"""
One-Click Local Deployment Script for College Query Chatbot
This script handles complete automated setup, dependency management, and deployment
"""

import os
import sys
import subprocess
import platform
import time
import json
import urllib.request
import shutil
from pathlib import Path

class Colors:
    """ANSI color codes for terminal output"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'

class LocalDeployment:
    def __init__(self):
        self.project_name = "College Query Chatbot"
        self.python_min_version = (3, 9)
        self.project_dir = Path.cwd()
        self.venv_dir = self.project_dir / "venv"
        self.requirements_file = "local_requirements.txt"
        self.env_file = ".env"
        self.is_windows = platform.system() == "Windows"
        
    def print_banner(self):
        """Display deployment banner"""
        print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*60}{Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}🎓 {self.project_name} - One-Click Deployment{Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}{'='*60}{Colors.END}\n")
        
    def log_info(self, message):
        """Log info message"""
        print(f"{Colors.BLUE}ℹ️  {message}{Colors.END}")
        
    def log_success(self, message):
        """Log success message"""
        print(f"{Colors.GREEN}✅ {message}{Colors.END}")
        
    def log_warning(self, message):
        """Log warning message"""
        print(f"{Colors.YELLOW}⚠️  {message}{Colors.END}")
        
    def log_error(self, message):
        """Log error message"""
        print(f"{Colors.RED}❌ {message}{Colors.END}")
        
    def run_command(self, command, description, capture_output=True, check=True):
        """Execute shell command with proper error handling"""
        self.log_info(f"Running: {description}")
        try:
            if capture_output:
                result = subprocess.run(
                    command, 
                    shell=True, 
                    check=check, 
                    capture_output=True, 
                    text=True,
                    timeout=300  # 5 minute timeout
                )
                return result
            else:
                result = subprocess.run(command, shell=True, check=check)
                return result
        except subprocess.TimeoutExpired:
            self.log_error(f"Command timed out: {description}")
            return None
        except subprocess.CalledProcessError as e:
            self.log_error(f"Command failed: {description}")
            if capture_output and e.stdout:
                print(f"Output: {e.stdout}")
            if capture_output and e.stderr:
                print(f"Error: {e.stderr}")
            return None
        except Exception as e:
            self.log_error(f"Unexpected error in {description}: {str(e)}")
            return None
    
    def check_python_version(self):
        """Verify Python version compatibility"""
        current_version = sys.version_info[:2]
        if current_version < self.python_min_version:
            self.log_error(f"Python {self.python_min_version[0]}.{self.python_min_version[1]}+ required")
            self.log_error(f"Current version: {current_version[0]}.{current_version[1]}")
            return False
        
        self.log_success(f"Python {current_version[0]}.{current_version[1]} detected")
        return True
    
    def check_internet_connection(self):
        """Check internet connectivity for package downloads"""
        try:
            urllib.request.urlopen('https://pypi.org', timeout=10)
            self.log_success("Internet connection verified")
            return True
        except Exception:
            self.log_warning("No internet connection - will try to use cached packages")
            return False
    
    def create_virtual_environment(self):
        """Create and activate virtual environment"""
        if self.venv_dir.exists():
            self.log_info("Virtual environment already exists")
            return True
            
        self.log_info("Creating virtual environment")
        result = self.run_command(
            f'"{sys.executable}" -m venv "{self.venv_dir}"',
            "Creating virtual environment"
        )
        
        if result and result.returncode == 0:
            self.log_success("Virtual environment created successfully")
            return True
        else:
            self.log_error("Failed to create virtual environment")
            return False
    
    def get_venv_python(self):
        """Get path to virtual environment Python executable"""
        if self.is_windows:
            return self.venv_dir / "Scripts" / "python.exe"
        else:
            return self.venv_dir / "bin" / "python"
    
    def get_venv_pip(self):
        """Get path to virtual environment pip executable"""
        if self.is_windows:
            return self.venv_dir / "Scripts" / "pip.exe"
        else:
            return self.venv_dir / "bin" / "pip"
    
    def install_dependencies(self):
        """Install Python dependencies"""
        pip_path = self.get_venv_pip()
        
        # Upgrade pip first
        self.log_info("Upgrading pip")
        result = self.run_command(
            f'"{pip_path}" install --upgrade pip',
            "Upgrading pip"
        )
        
        if not result or result.returncode != 0:
            self.log_warning("Failed to upgrade pip, continuing with current version")
        
        # Install requirements
        if not Path(self.requirements_file).exists():
            self.log_error(f"Requirements file {self.requirements_file} not found")
            return False
        
        self.log_info(f"Installing dependencies from {self.requirements_file}")
        result = self.run_command(
            f'"{pip_path}" install -r "{self.requirements_file}"',
            "Installing Python packages"
        )
        
        if result and result.returncode == 0:
            self.log_success("Dependencies installed successfully")
            return True
        else:
            self.log_error("Failed to install dependencies")
            return False
    
    def create_env_file(self):
        """Create .env file with default configuration"""
        if Path(self.env_file).exists():
            self.log_info("Environment file already exists")
            return True
        
        env_content = """# College Query Chatbot - Environment Configuration
# Created by automatic deployment script

# Required - Get your API key from https://aistudio.google.com/app/apikey
GEMINI_API_KEY=your_gemini_api_key_here

# Optional - Session security (change for production)
SESSION_SECRET=dev-secret-key-change-in-production-environment

# Optional - Database configuration
DATABASE_URL=sqlite:///instance/chatbot.db

# Development settings
FLASK_ENV=development
FLASK_DEBUG=True

# Application configuration
HOST=0.0.0.0
PORT=5000

# Logging configuration
LOG_LEVEL=INFO
"""
        
        try:
            with open(self.env_file, 'w') as f:
                f.write(env_content)
            self.log_success("Environment file created")
            return True
        except Exception as e:
            self.log_error(f"Failed to create environment file: {str(e)}")
            return False
    
    def create_directories(self):
        """Create necessary project directories"""
        directories = [
            "instance",
            "static/css", 
            "static/js",
            "templates",
            "logs"
        ]
        
        for directory in directories:
            dir_path = Path(directory)
            if not dir_path.exists():
                try:
                    dir_path.mkdir(parents=True, exist_ok=True)
                    self.log_info(f"Created directory: {directory}")
                except Exception as e:
                    self.log_error(f"Failed to create directory {directory}: {str(e)}")
                    return False
        
        self.log_success("Project directories created")
        return True
    
    def test_installation(self):
        """Test the installation by importing key modules"""
        python_path = self.get_venv_python()
        
        test_imports = [
            "flask",
            "flask_sqlalchemy", 
            "google.genai",
            "trafilatura",
            "requests"
        ]
        
        self.log_info("Testing installation")
        for module in test_imports:
            result = self.run_command(
                f'"{python_path}" -c "import {module}; print(f\'{module} OK\')"',
                f"Testing {module} import"
            )
            
            if not result or result.returncode != 0:
                self.log_error(f"Failed to import {module}")
                return False
        
        self.log_success("All dependencies tested successfully")
        return True
    
    def create_startup_scripts(self):
        """Create platform-specific startup scripts"""
        
        # Windows batch file
        if self.is_windows:
            batch_content = f"""@echo off
echo Starting {self.project_name}...
cd /d "{self.project_dir}"
"{self.get_venv_python()}" run_local.py
pause
"""
            try:
                with open("start_chatbot.bat", 'w') as f:
                    f.write(batch_content)
                self.log_success("Windows startup script created: start_chatbot.bat")
            except Exception as e:
                self.log_warning(f"Failed to create Windows startup script: {str(e)}")
        
        # Unix shell script
        shell_content = f"""#!/bin/bash
echo "Starting {self.project_name}..."
cd "{self.project_dir}"
source "{self.venv_dir}/bin/activate"
python run_local.py
"""
        try:
            with open("start_chatbot.sh", 'w') as f:
                f.write(shell_content)
            os.chmod("start_chatbot.sh", 0o755)  # Make executable
            self.log_success("Unix startup script created: start_chatbot.sh")
        except Exception as e:
            self.log_warning(f"Failed to create Unix startup script: {str(e)}")
    
    def display_completion_info(self):
        """Display completion information and next steps"""
        print(f"\n{Colors.GREEN}{Colors.BOLD}🎉 Deployment Completed Successfully!{Colors.END}")
        print(f"{Colors.CYAN}{'='*50}{Colors.END}")
        
        print(f"\n{Colors.BOLD}📋 Next Steps:{Colors.END}")
        print(f"{Colors.YELLOW}1. Get your Gemini API key:{Colors.END}")
        print(f"   • Visit: https://aistudio.google.com/app/apikey")
        print(f"   • Create a new API key")
        print(f"   • Edit {self.env_file} and replace 'your_gemini_api_key_here'")
        
        print(f"\n{Colors.YELLOW}2. Start the application:{Colors.END}")
        if self.is_windows:
            print(f"   • Double-click: start_chatbot.bat")
            print(f"   • Or run: python run_local.py")
        else:
            print(f"   • Run: ./start_chatbot.sh")
            print(f"   • Or run: python run_local.py")
        
        print(f"\n{Colors.YELLOW}3. Access your chatbot:{Colors.END}")
        print(f"   • Open: http://localhost:5000")
        print(f"   • Start asking questions about colleges!")
        
        print(f"\n{Colors.BOLD}🛠️  Development Commands:{Colors.END}")
        if self.is_windows:
            print(f"   • Activate environment: venv\\Scripts\\activate")
        else:
            print(f"   • Activate environment: source venv/bin/activate")
        print(f"   • Run in debug mode: python run_local.py")
        print(f"   • Run tests: python -m pytest (if tests added)")
        
        print(f"\n{Colors.BOLD}📁 Project Structure:{Colors.END}")
        print(f"   • Main app: app.py, main.py, routes.py")
        print(f"   • AI service: ai_service.py")
        print(f"   • Web scraping: web_scraper.py")
        print(f"   • Database: instance/chatbot.db")
        print(f"   • Frontend: templates/ and static/")
        
        print(f"\n{Colors.GREEN}Your college query chatbot is ready to use!{Colors.END}\n")
    
    def run_deployment(self):
        """Main deployment process"""
        self.print_banner()
        
        # Pre-flight checks
        if not self.check_python_version():
            return False
        
        self.check_internet_connection()
        
        # Main deployment steps
        steps = [
            ("Creating project directories", self.create_directories),
            ("Creating virtual environment", self.create_virtual_environment),
            ("Installing dependencies", self.install_dependencies),
            ("Creating environment file", self.create_env_file),
            ("Testing installation", self.test_installation),
            ("Creating startup scripts", self.create_startup_scripts)
        ]
        
        for step_name, step_func in steps:
            self.log_info(f"Step: {step_name}")
            if not step_func():
                self.log_error(f"Deployment failed at: {step_name}")
                return False
            time.sleep(0.5)  # Brief pause for readability
        
        self.display_completion_info()
        return True

def main():
    """Main entry point"""
    deployment = LocalDeployment()
    
    try:
        success = deployment.run_deployment()
        if success:
            sys.exit(0)
        else:
            print(f"\n{Colors.RED}Deployment failed. Please check the errors above.{Colors.END}")
            sys.exit(1)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Deployment cancelled by user.{Colors.END}")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}Unexpected error: {str(e)}{Colors.END}")
        sys.exit(1)

if __name__ == "__main__":
    main()