#!/usr/bin/env python3
"""
Test Gemini API integration
"""
import os
import logging

def test_gemini_api():
    """Test Gemini API directly"""
    try:
        from google import genai
        from google.genai import types
        
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            print("❌ GEMINI_API_KEY not found in environment")
            return False
        
        print(f"✅ GEMINI_API_KEY found (length: {len(api_key)} chars)")
        
        # Initialize client
        client = genai.Client(api_key=api_key)
        print("✅ Gemini client initialized successfully")
        
        # Test API call
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents="Test: Say 'Gemini API working'",
            config=types.GenerateContentConfig(
                max_output_tokens=20,
                temperature=0.1
            )
        )
        
        result = response.text if response.text else "No response"
        print(f"✅ Gemini API Test: SUCCESS")
        print(f"Response: {result}")
        return True
        
    except Exception as e:
        print(f"❌ Gemini API Test: FAILED - {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Testing Gemini API Integration")
    print("=" * 50)
    
    success = test_gemini_api()
    
    if success:
        print("\n✅ Gemini integration is working!")
    else:
        print("\n❌ Gemini integration needs attention")