# College Query Chatbot

## Overview

This is a Flask-based web application that creates an AI-powered chatbot designed to answer questions about colleges, admissions, courses, and campus life. The system allows users to scrape college websites and use that data to provide more informed responses through AI language models.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Flask web framework with SQLAlchemy ORM
- **Database**: SQLite (configurable via DATABASE_URL environment variable)
- **AI Integration**: Dual AI provider support (OpenAI and Anthropic Claude)
- **Web Scraping**: Trafilatura library for extracting clean text content from websites

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **CSS Framework**: Bootstrap 5 with Replit dark theme
- **JavaScript**: Vanilla JavaScript for chat functionality and real-time interactions
- **UI Components**: Responsive design with chat interface and website management sidebar

### Key Design Decisions
1. **Dual AI Provider Support**: The system can work with either OpenAI or Anthropic APIs, providing flexibility and fallback options
2. **Session-Based Chat**: Each user gets a unique session with persistent chat history
3. **Website Data Enhancement**: Users can add college websites to improve response accuracy
4. **Simple Database Schema**: Three main models for sessions, messages, and website data

## Key Components

### Models (models.py)
- **ChatSession**: Stores unique user sessions with timestamps
- **ChatMessage**: Individual message/response pairs linked to sessions
- **WebsiteData**: Scraped website content with metadata

### AI Service (ai_service.py)
- Handles communication with OpenAI and Anthropic APIs
- Provides context from scraped website data
- Implements graceful fallback between AI providers

### Web Scraper (web_scraper.py)
- Uses Trafilatura for clean text extraction
- Validates educational institution URLs
- Handles scraping errors gracefully

### Routes (routes.py)
- Main chat interface endpoint
- AJAX endpoints for real-time chat
- Website scraping endpoints
- Session management

## Data Flow

1. **User Interaction**: User sends message through chat interface
2. **Context Building**: System retrieves recent chat history and relevant website data
3. **AI Processing**: Message sent to available AI provider with context
4. **Response Storage**: Both user message and AI response stored in database
5. **Real-time Update**: Response displayed to user via AJAX

### Website Data Enhancement Flow
1. User enters college website URL
2. System validates URL for educational content
3. Trafilatura scrapes and extracts clean text
4. Content stored in database for future reference
5. Data used to enhance AI responses about that institution

## External Dependencies

### Required Python Packages
- Flask and Flask-SQLAlchemy for web framework
- OpenAI SDK (optional)
- Anthropic SDK (optional)
- Trafilatura for web scraping
- Werkzeug for WSGI utilities

### Frontend Dependencies
- Bootstrap 5 (CDN)
- Font Awesome (CDN)
- Bootstrap Replit dark theme (CDN)

### Environment Variables
- `OPENAI_API_KEY`: OpenAI API access
- `ANTHROPIC_API_KEY`: Anthropic API access
- `DATABASE_URL`: Database connection string (defaults to SQLite)
- `SESSION_SECRET`: Flask session encryption key

## Deployment Strategy

### Development Setup
- SQLite database with automatic table creation
- Debug mode enabled
- Runs on host 0.0.0.0:5000

### Production Considerations
- Database URL should point to production database (PostgreSQL recommended)
- SESSION_SECRET must be set to secure value
- Debug mode should be disabled
- Proxy fix enabled for HTTPS handling

### Database Migration
- Uses SQLAlchemy with automatic table creation
- No migration system currently implemented
- Database schema changes require manual handling

### Error Handling
- Comprehensive logging for debugging
- Graceful degradation when AI services unavailable
- User-friendly error messages for scraping failures
- Session recovery mechanisms

The application is designed to be easily deployable on Replit with minimal configuration, while remaining flexible enough for production deployment with proper environment variables.