import os
import logging
import re
from typing import List, Optional
from collections import Counter

# Try to import OpenAI first
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# Try to import Google Gemini
try:
    from google import genai
    from google.genai import types
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

# Try to import Anthropic
try:
    import anthropic
    from anthropic import Anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

from models import WebsiteData

# Initialize AI clients
openai_client = None
gemini_client = None
anthropic_client = None

if OPENAI_AVAILABLE:
    openai_api_key = os.environ.get("OPENAI_API_KEY")
    if openai_api_key:
        try:
            openai_client = OpenAI(api_key=openai_api_key)
        except Exception as e:
            logging.error(f"Failed to initialize OpenAI client: {e}")

if GEMINI_AVAILABLE:
    gemini_api_key = os.environ.get("GEMINI_API_KEY")
    if gemini_api_key:
        try:
            gemini_client = genai.Client(api_key=gemini_api_key)
            logging.info("✅ Gemini client initialized successfully")
        except Exception as e:
            logging.error(f"Failed to initialize Gemini client: {e}")
    else:
        logging.info("No GEMINI_API_KEY found")
else:
    logging.info("Gemini not available - import failed")

if ANTHROPIC_AVAILABLE:
    anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY")
    if anthropic_api_key:
        try:
            anthropic_client = Anthropic(api_key=anthropic_api_key)
        except Exception as e:
            logging.error(f"Failed to initialize Anthropic client: {e}")

def get_relevant_website_data(query: str) -> str:
    """Get relevant website data based on the query"""
    try:
        # Get all website data (in a real application, you'd want to implement
        # more sophisticated search/matching)
        websites = WebsiteData.query.all()
        
        if not websites:
            return "No website data available. Please scrape some college websites first."
        
        # Simple keyword matching - in production, you'd want semantic search
        relevant_content = []
        query_lower = query.lower()
        
        for site in websites:
            if site.content:
                content_lower = site.content.lower()
                # Check if query keywords appear in content
                if any(word in content_lower for word in query_lower.split()):
                    # Take first 1000 characters to avoid token limits
                    relevant_content.append(f"From {site.url}:\n{site.content[:1000]}...")
        
        if relevant_content:
            return "\n\n".join(relevant_content)
        else:
            # Return some content even if no direct matches
            return f"Available college information from {len(websites)} websites:\n\n" + \
                   "\n\n".join([f"From {site.url}:\n{site.content[:500]}..." 
                               for site in websites[:3]])
    
    except Exception as e:
        logging.error(f"Error getting website data: {str(e)}")
        return "Error retrieving website data."

def extract_keywords(text: str) -> List[str]:
    """Extract important keywords from text"""
    # Remove common stop words and extract meaningful words
    stop_words = {'the', 'is', 'at', 'which', 'on', 'and', 'a', 'to', 'are', 'as', 'was', 'were', 
                  'been', 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 
                  'should', 'may', 'might', 'can', 'of', 'in', 'for', 'with', 'by', 'from', 'up', 
                  'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 
                  'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further',
                  'then', 'once', 'very', 'also', 'just', 'only', 'more', 'most', 'some', 'any', 'all'}
    
    # Extract words and filter
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
    keywords = [word for word in words if word not in stop_words]
    
    # Return most common keywords
    return [word for word, count in Counter(keywords).most_common(20)]

def analyze_content_locally(query: str, website_content: str) -> str:
    """Analyze website content without AI APIs using keyword matching and text processing"""
    try:
        query_lower = query.lower()
        
        # Extract relevant sentences based on query keywords
        sentences = re.split(r'[.!?]+', website_content)
        relevant_sentences = []
        
        query_words = [word for word in query_lower.split() if len(word) > 2]
        
        for sentence in sentences:
            if not sentence.strip():
                continue
                
            sentence_lower = sentence.lower()
            # Score sentence based on keyword matches
            score = sum(1 for word in query_words if word in sentence_lower)
            if score > 0:
                relevant_sentences.append((sentence.strip(), score))
        
        # Sort by relevance and take top sentences
        relevant_sentences.sort(key=lambda x: x[1], reverse=True)
        top_sentences = [sent[0] for sent in relevant_sentences[:5] if sent[0]]
        
        if top_sentences:
            response = "Based on the website information, here's what I found:\n\n"
            response += "\n\n".join(top_sentences)
            response += "\n\nThis information was extracted from the college website."
            return response
        else:
            # Return some general content if no specific matches
            first_sentences = [s.strip() for s in sentences[:3] if s.strip()]
            if first_sentences:
                return "Here's some general information from the college website:\n\n" + "\n\n".join(first_sentences)
            else:
                return "I found some content on the website, but couldn't extract specific information matching your question. Try asking about admissions, programs, or facilities."
                
    except Exception as e:
        logging.error(f"Error in analyze_content_locally: {str(e)}")
        return "I found some information but had trouble analyzing it. Please try rephrasing your question."

def get_local_fallback_response(user_message: str, website_data: str) -> str:
    """Provide responses using local text analysis when no API is available"""
    if not website_data or "No website data available" in website_data:
        return """I'm a college query chatbot that can help answer questions about colleges, admissions, courses, and campus life. 

To get specific information, please:
1. Add college websites using the sidebar on the left
2. Ask questions about admissions, tuition, programs, or campus life

Some example questions you can ask:
- What are the admission requirements?
- How much does tuition cost?
- What programs are available?
- What facilities are on campus?

I'll analyze the website content to provide you with accurate information!"""
    
    try:
        return analyze_content_locally(user_message, website_data)
    except Exception as e:
        logging.error(f"Error in local analysis: {str(e)}")
        return "I found some information on the website, but had trouble analyzing it. Could you try rephrasing your question or being more specific about what you'd like to know?"

def get_ai_response(user_message: str, context: Optional[List[str]] = None) -> str:
    """Get AI response using available AI service or local fallback"""
    try:
        # Get relevant website data
        website_data = get_relevant_website_data(user_message)
        
        # Try Gemini first if API key is available
        if gemini_client:
            try:
                logging.info("Using Google Gemini for enhanced responses")
                
                # Prepare system message with website data
                prompt = f"""You are an expert college admissions counselor and educational consultant. You help students with college-related questions including admissions, courses, campus life, facilities, and career guidance.

Use the following college website data to provide accurate, specific information:

{website_data}

Guidelines:
- Provide detailed, helpful information about colleges and education
- Be conversational, friendly, and encouraging 
- If you don't have specific information from the website data, say so clearly
- When referring to website information, mention it came from the college website
- Focus on being helpful for prospective students and their families
- Provide actionable advice and next steps when appropriate

Student Question: {user_message}

Please provide a helpful response based on the college information above."""

                # Call Gemini API
                response = gemini_client.models.generate_content(
                    model="gemini-2.5-flash",  # Latest Gemini model
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        max_output_tokens=1000,
                        temperature=0.7
                    )
                )
                
                ai_response = response.text if response.text else None
                if ai_response:
                    return ai_response
                    
            except Exception as e:
                logging.error(f"Gemini API error: {str(e)}")
                # Fall back to ChatGPT if available
        
        # Try ChatGPT (OpenAI) as fallback if API key is available
        if openai_client:
            try:
                logging.info("Using ChatGPT for enhanced responses")
                
                # Prepare system message with website data
                system_message = f"""You are an expert college admissions counselor and educational consultant. You help students with college-related questions including admissions, courses, campus life, facilities, and career guidance.

Use the following college website data to provide accurate, specific information:

{website_data}

Guidelines:
- Provide detailed, helpful information about colleges and education
- Be conversational, friendly, and encouraging 
- If you don't have specific information from the website data, say so clearly
- When referring to website information, mention it came from the college website
- Focus on being helpful for prospective students and their families
- Provide actionable advice and next steps when appropriate
"""

                # Prepare conversation messages
                messages = [{"role": "system", "content": system_message}]
                
                # Add previous context if available
                if context:
                    for ctx in context[-4:]:  # Last 4 messages for context
                        if ctx.startswith("User: "):
                            messages.append({"role": "user", "content": ctx[6:]})
                        elif ctx.startswith("Assistant: "):
                            messages.append({"role": "assistant", "content": ctx[11:]})
                
                # Add current user message
                messages.append({"role": "user", "content": user_message})
                
                # Call ChatGPT API
                response = openai_client.chat.completions.create(
                    model="gpt-4o",  # Latest OpenAI model
                    messages=messages,
                    max_tokens=1000,
                    temperature=0.7
                )
                
                ai_response = response.choices[0].message.content
                if ai_response:
                    return ai_response
                    
            except Exception as e:
                logging.error(f"ChatGPT API error: {str(e)}")
                # Fall back to local analysis if API fails
        
        # Use enhanced local analysis when no API is available
        logging.info("Using enhanced local analysis for college queries")
        return get_enhanced_local_response(user_message, website_data, context)
    
    except Exception as e:
        logging.error(f"Error in get_ai_response: {str(e)}")
        return "I apologize, but I encountered an error while processing your request. Please try again or add some college websites for better responses."

def get_enhanced_local_response(user_message: str, website_data: str, context: Optional[List[str]] = None) -> str:
    """Enhanced local analysis with better conversation and context awareness"""
    if not website_data or "No website data available" in website_data:
        return get_welcome_response()
    
    query_lower = user_message.lower()
    
    college_categories = {
        'admissions': ['admission', 'apply', 'application', 'requirements', 'eligibility', 'entrance', 'exam', 'gpa', 'sat', 'act', 'deadlines', 'cutoff'],
        'programs': ['courses', 'programs', 'majors', 'degree', 'curriculum', 'subjects', 'departments', 'engineering', 'medical', 'business', 'arts'],
        'fees': ['fees', 'tuition', 'cost', 'financial', 'scholarship', 'payment', 'expensive', 'affordable', 'money'],
        'campus': ['campus', 'facilities', 'hostel', 'accommodation', 'library', 'labs', 'sports', 'placement', 'infrastructure'],
        'location': ['location', 'address', 'where', 'city', 'state', 'contact', 'phone', 'email'],
        'general': ['about', 'history', 'established', 'university', 'college', 'overview', 'mission']
    }
    
    # Find best matching category
    best_category = 'general'
    max_score = 0
    
    for category, keywords in college_categories.items():
        score = sum(1 for keyword in keywords if keyword in query_lower)
        if score > max_score:
            max_score = score
            best_category = category
    
    # Extract relevant information based on category and query
    try:
        return analyze_content_with_category(user_message, website_data, best_category)
    except Exception as e:
        logging.error(f"Error in enhanced local response: {str(e)}")
        return analyze_content_locally(user_message, website_data)

def analyze_content_with_category(query: str, website_content: str, category: str, context: str = "") -> str:
    """Analyze content with category-specific focus"""
    query_lower = query.lower()
    
    # Extract sentences and score them
    sentences = re.split(r'[.!?]+', website_content)
    relevant_sentences = []
    
    # Category-specific keyword boosting
    category_boost = {
        'admissions': ['admission', 'eligibility', 'entrance', 'application', 'exam'],
        'programs': ['engineering', 'medical', 'course', 'degree', 'program', 'department'],
        'fees': ['fee', 'cost', 'tuition', 'scholarship', 'payment'],
        'campus': ['campus', 'facility', 'hostel', 'library', 'lab', 'placement'],
        'location': ['address', 'location', 'contact', 'phone', 'email'],
        'general': ['university', 'college', 'established', 'about']
    }
    
    boost_words = category_boost.get(category, [])
    query_words = [word for word in query_lower.split() if len(word) > 2]
    
    for sentence in sentences:
        if not sentence.strip():
            continue
            
        sentence_lower = sentence.lower()
        score = 0
        
        # Score based on query words
        for word in query_words:
            if word in sentence_lower:
                score += 2
        
        # Boost score for category-relevant words
        for boost_word in boost_words:
            if boost_word in sentence_lower:
                score += 1
        
        # Length penalty for very short sentences
        if len(sentence.strip()) < 20:
            score -= 1
            
        if score > 0:
            relevant_sentences.append((sentence.strip(), score))
    
    # Sort by relevance and format response
    relevant_sentences.sort(key=lambda x: x[1], reverse=True)
    top_sentences = [sent[0] for sent in relevant_sentences[:4] if sent[0] and sent[1] > 0]
    
    if top_sentences:
        # Create category-specific response introduction
        category_intros = {
            'admissions': "Here's what I found about admissions and application requirements:",
            'programs': "Here are the academic programs and courses available:",
            'fees': "Here's information about fees and financial details:",
            'campus': "Here's what I found about campus facilities and student life:",
            'location': "Here's the location and contact information:",
            'general': "Here's general information about the institution:"
        }
        
        intro = category_intros.get(category, "Based on your question, here's what I found:")
        response = f"{intro}\n\n"
        response += "\n\n".join(top_sentences)
        response += "\n\n📍 This information is from the college website. Feel free to ask more specific questions!"
        
        return response
    else:
        return get_category_fallback_response(category, website_content)

def get_category_fallback_response(category: str, website_content: str) -> str:
    """Provide helpful fallback responses based on category"""
    fallback_responses = {
        'admissions': "I couldn't find specific admission details in the website content. Try asking about 'application process', 'entrance exams', or 'eligibility criteria'.",
        'programs': "I couldn't find specific program information. Try asking about 'engineering courses', 'degree programs', or 'available departments'.",
        'fees': "I couldn't find fee details in the content. Try asking about 'tuition fees', 'scholarship programs', or 'payment structure'.",
        'campus': "I couldn't find campus information. Try asking about 'facilities', 'hostel accommodation', or 'campus infrastructure'.",
        'location': "I couldn't find location details. Try asking about 'college address', 'contact information', or 'how to reach'.",
        'general': "Let me share some general information from the website."
    }
    
    fallback = fallback_responses.get(category, "I found some information but couldn't match your specific question.")
    
    # Try to get some general content
    sentences = [s.strip() for s in re.split(r'[.!?]+', website_content) if s.strip()][:2]
    if sentences:
        fallback += f"\n\nHere's some general information: {' '.join(sentences)}"
    
    return fallback

def get_welcome_response() -> str:
    """Welcome response when no website data is available"""
    return """👋 Welcome to the College Query Chatbot! 

I'm here to help you with college-related questions. To provide you with accurate and specific information, please:

🌐 **Add college websites** using the sidebar on the left
   - Enter any college website URL (like www.university.edu)
   - I'll analyze the content to answer your questions

💬 **Ask me about:**
   - Admission requirements and application process
   - Available courses and degree programs  
   - Fees, scholarships, and financial aid
   - Campus facilities and student life
   - Location and contact information

Once you add some college websites, I can provide detailed, accurate answers based on real college information!

🤖 **Pro tip:** I work even better with ChatGPT when you add an OpenAI API key, but I can help you right now with the websites you add."""
