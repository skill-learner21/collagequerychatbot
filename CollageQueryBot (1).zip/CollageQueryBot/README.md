# College Query Chatbot - Local Setup Guide

An AI-powered college query chatbot that provides intelligent, conversational responses about colleges using Google Gemini AI integration and web scraping capabilities.

## Features

- 🤖 **Google Gemini AI Integration** - Smart, conversational responses about college information
- 🌐 **Web Scraping** - Analyzes college websites to provide accurate, up-to-date information
- 💬 **Modern Chat Interface** - Beautiful, responsive UI with university-inspired design
- 📱 **Mobile Responsive** - Works perfectly on all devices
- 🎨 **Professional Design** - Modern gradients, animations, and typography

## Local Development Setup

### Prerequisites

- Python 3.9 or higher
- VS Code (recommended) or any code editor
- Git (for version control)

### Step 1: Clone/Download the Project

1. Download all project files to your local machine
2. Extract to a folder (e.g., `college-chatbot`)
3. Open the folder in VS Code

### Step 2: Create Virtual Environment

```bash
# Navigate to project directory
cd college-chatbot

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
# Install all required packages
pip install flask flask-sqlalchemy google-genai trafilatura requests werkzeug gunicorn psycopg2-binary
```

### Step 4: Set Environment Variables

Create a `.env` file in the project root:

```env
# Required - Get from Google AI Studio (https://aistudio.google.com/app/apikey)
GEMINI_API_KEY=your_gemini_api_key_here

# Optional - for session security
SESSION_SECRET=your_secret_key_here

# Optional - database (defaults to SQLite)
DATABASE_URL=sqlite:///instance/chatbot.db
```

### Step 5: Project Structure

Your project should look like this:
```
college-chatbot/
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── chat.js
├── templates/
│   ├── base.html
│   └── index.html
├── instance/
│   └── chatbot.db (created automatically)
├── app.py
├── main.py
├── routes.py
├── models.py
├── ai_service.py
├── web_scraper.py
├── .env
├── requirements.txt
└── README.md
```

### Step 6: Run the Application

```bash
# Make sure virtual environment is activated
# Run the development server
python main.py

# Or using Flask directly
flask run --host=0.0.0.0 --port=5000

# Or using Gunicorn (production-like)
gunicorn --bind 0.0.0.0:5000 --reload main:app
```

The application will be available at: http://localhost:5000

## Getting Your Gemini API Key

1. Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy the key and add it to your `.env` file

## Usage

1. **Start chatting** - Ask questions about colleges, admissions, programs, fees
2. **Add websites** - Use the sidebar to scrape college websites for more accurate responses
3. **Clear chat** - Use the "Clear Chat" button to start a new session

## Example Queries

- "Tell me about admission requirements"
- "What programs does the university offer?"
- "What are the tuition fees?"
- "Tell me about campus facilities"
- "How do I apply for scholarships?"

## Customization

### Adding New AI Providers
- Edit `ai_service.py` to add OpenAI or Anthropic support
- Update environment variables accordingly

### Styling Changes
- Modify `static/css/style.css` for design changes
- Update color variables in the CSS for different themes

### Database Configuration
- For PostgreSQL: Update `DATABASE_URL` in `.env`
- For MySQL: Install mysql-connector-python and update URL

## Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

2. **Database Issues**
   - Delete `instance/chatbot.db` to reset database
   - Check file permissions in instance folder

3. **API Errors**
   - Verify your Gemini API key is correct
   - Check your internet connection
   - Ensure you have API quota remaining

4. **Scraping Issues**
   - Some websites block scraping - this is normal
   - Try different URLs if one doesn't work
   - Check the website's robots.txt file

## Deployment Options

### Local Network Access
```bash
# Run on all network interfaces
python main.py --host=0.0.0.0
```

### Production Deployment
- Use a production WSGI server like Gunicorn
- Set `SESSION_SECRET` to a secure random value
- Use PostgreSQL for production database
- Enable HTTPS

## Support

For issues or questions:
1. Check the console/terminal for error messages
2. Verify all environment variables are set correctly
3. Ensure all dependencies are installed

## License

This project is for educational purposes. Please respect website terms of service when scraping.